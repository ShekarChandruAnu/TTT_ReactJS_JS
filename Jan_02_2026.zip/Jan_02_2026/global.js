//User Defined Method
function addEvent(obj,evt,func)
{
/*
window - predefined Object  
*/
	obj.addEventListener(evt,func,false);
}
addEvent(window,'load',initialize);
function initialize()
{
var mySubmit = document.getElementById('sub1');
addEvent(mySubmit,'click',processData);

}
function processData()
{
var eName = document.getElementById('empName').value;
var eAddr = document.getElementById('empAddress').value;
alert('Hi '+eName+' Residing at '+eAddr+'Welcoming you to Event Handling and DOM');
}
